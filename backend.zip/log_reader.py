import re
import time
from datetime import datetime
from db import save_access, inc_metric
import subprocess

# 1. Captura usuário autenticado no log
PATTERN_USER = re.compile(r'uname=([^\s]+)')

# 2. Captura UID do dashboard quando vier pela UI (/d/<uid>)
PATTERN_UID = re.compile(r'path=/d/(?P<uid>[a-zA-Z0-9\-_]+)(?:/|$)')

# 3. Captura nome do dashboard quando vier pela UI (/d/<uid>/<slug>)
PATTERN_NAME = re.compile(r'path=/d/[a-zA-Z0-9\-_]+/(?P<slug>[^\s?]+)')

# 4. Captura UID + slug a partir do referer (fallback assertivo)
PATTERN_REF_NAME = re.compile(r'referer="[^"]*/d/(?P<uid>[a-zA-Z0-9\-_]+)/(?P<slug>[^"?/]+)')

last_access_time = {}
DEDUPE_SECONDS = 5

def extract_username(log_line):
    m = PATTERN_USER.search(log_line)
    return m.group(1) if m else None

def extract_dashboard_uid(log_line):
    m = PATTERN_UID.search(log_line)
    if m:
        return m.group("uid")
    # fallback via referer
    m2 = PATTERN_REF_NAME.search(log_line)
    return m2.group("uid") if m2 else None

def extract_dashboard_name(log_line, dashboard_uid):
    # 1. tenta via UI
    m = PATTERN_NAME.search(log_line)
    if m:
        return m.group("slug")
    # 2. tenta via referer
    m2 = PATTERN_REF_NAME.search(log_line)
    if m2:
        return m2.group("slug")
    # 3. fallback final: UID
    return dashboard_uid

def should_process_access(username, dashboard_uid):
    key = f"{username}_{dashboard_uid}"
    now = time.time()
    if key in last_access_time and (now - last_access_time[key] < DEDUPE_SECONDS):
        return False
    last_access_time[key] = now
    return True

def process_log_line(log_line):
    try:
        user = extract_username(log_line)
        uid  = extract_dashboard_uid(log_line)

        if not user or not uid:
            return  # ignora ❌

        if not should_process_access(user, uid):
            return  # dedupe ❌

        name = extract_dashboard_name(log_line, uid)
        ts = datetime.utcnow()

        print(f"🔥 Dashboard acessado → user={user} uid={uid} dash={name} at={ts}")

        save_access(user, uid, ts)
        inc_metric(uid, name)

    except Exception as e:
        print(f"🔥 Erro ao processar log: {e}")

def read_logs():
    print("📡 Monitorando logs do Grafana no ARO...")

    cmd = [
        "oc", "logs",
        "-n", "nm-observ",
        "-l", "app.kubernetes.io/instance=lgtm-deploy",
        "-c", "grafana",
        "-f",
        "--tail=0"
    ]

    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1)

    for line in iter(proc.stdout.readline, ""):
        line = line.strip()
        if line:
            process_log_line(line)

if __name__ == "__main__":
    read_logs()
